create database myblog;
use myblog;

show tables;
select * from my_posts;
select * from posts;
