//package com.springboot.blog.repository;
//
//import org.springframework.boot.actuate.autoconfigure.metrics.MetricsProperties.Data.Repository;
//
//public class DemoRepository extends Repository{
//
//}
